import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { NextResponse, type NextRequest } from "next/server";

/**
 * Verifica si el usuario está autenticado.
 * Acepta DOS formas de autenticación:
 * 1. NextAuth session (cookie next-auth.session-token)
 * 2. Cookie simple nexus-admin-session (fallback cuando BD no funciona)
 *
 * IMPORTANTE: El parámetro `req` es NECESARIO para que funcione en serverless.
 */
export async function requireAdmin(req?: NextRequest) {
  // 1. Intentar NextAuth primero
  try {
    const session = await getServerSession(authOptions);
    if (session?.user) {
      return { ok: true as const, session };
    }
  } catch (e) {
    console.log("⚠️ NextAuth falló, intentando cookie simple");
  }

  // 2. Fallback: cookie simple nexus-admin-session
  if (req) {
    // Método 1: req.cookies.get (estándar Next.js)
    const simpleSession = req.cookies.get("nexus-admin-session");
    if (simpleSession) {
      const authorized = checkSimpleSession(simpleSession);
      if (authorized) {
        return createSuccessSession();
      }
    }
  }

  // 3. Método 2: leer cookie del header manualmente (fallback)
  try {
    const cookieHeader = req?.headers?.get("cookie") || "";
    const match = cookieHeader.match(/nexus-admin-session=([^;]+)/);
    if (match) {
      const cookieValue = decodeURIComponent(match[1]);
      const authorized = checkSimpleSession(cookieValue);
      if (authorized) {
        return createSuccessSession();
      }
    }
  } catch (e) {
    // ignore
  }

  return {
    ok: false as const,
    response: NextResponse.json({ error: "No autorizado" }, { status: 401 }),
  };
}

function checkSimpleSession(cookieValue: string): boolean {
  try {
    const decoded = Buffer.from(cookieValue, "base64").toString();
    const [email] = decoded.split(":");
    return email === "admin@trackela.co";
  } catch {
    return false;
  }
}

function createSuccessSession() {
  return {
    ok: true as const,
    session: {
      user: {
        email: "admin@trackela.co",
        name: "Administrador",
        role: "admin",
        id: "admin-fallback",
      },
      expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    },
  };
}
