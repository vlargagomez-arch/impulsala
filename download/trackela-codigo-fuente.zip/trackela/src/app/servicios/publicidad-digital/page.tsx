import type { Metadata } from "next";
import { ServicePage, type ServicePageData } from "@/components/site/service-page";

export const metadata: Metadata = {
  title: "Campañas Publicitarias (Google Ads, Meta Ads) | Trackela Colombia",
  description:
    "Marketing digital que genera leads, no solo likes. Google Ads, Meta Ads, TikTok Ads y YouTube Ads. ROI promedio 340%. Desde $1.5M COP/mes para PYMES en Colombia.",
  alternates: {
    canonical: "https://w14nq5fjb3z1-d.space-z.ai/servicios/publicidad-digital",
  },
  openGraph: {
    title: "Campañas Publicitarias (Google Ads, Meta Ads) | Trackela Colombia",
    description:
      "Marketing digital que genera leads, no solo likes. Google Ads, Meta Ads, TikTok Ads y YouTube Ads. ROI promedio 340%.",
    url: "https://w14nq5fjb3z1-d.space-z.ai/servicios/publicidad-digital",
    type: "website",
  },
};

const DATA: ServicePageData = {
  slug: "publicidad-digital",
  title: "Campañas Publicitarias | Trackela Colombia",
  h1: "Campañas Publicitarias",
  description: "Marketing digital con ROI medible",
  metaDescription:
    "Marketing digital que genera leads, no solo likes. Google Ads, Meta Ads, TikTok Ads y YouTube Ads. ROI promedio 340%.",
  emoji: "📢",
  intro:
    "Marketing digital que genera leads, no solo likes. Diseñamos, gestionamos y optimizamos campañas en Google Ads, Meta Ads, TikTok Ads y YouTube Ads para PYMES en Colombia. Cada peso invertido genera resultados medibles. Tu agencia de marketing digital en Bogotá con ROI promedio del 340%.",
  benefits: [
    "ROI promedio del 340% en los primeros 90 días",
    "Leads cualificados, no solo impresiones o clics",
    "Optimización semanal con datos reales, no suposiciones",
    "Segmentación precisa por ubicación, edad, intereses y comportamiento",
    "Reportes transparentes cada semana",
    "Sin contratos de permanencia",
  ],
  features: [
    {
      title: "Google Ads (Search, Display, YouTube)",
      description:
        "Apareces cuando tus clientes te buscan. Search Ads para intención alta, Display para branding, YouTube Ads para alcance masivo. Optimización de calidad de anuncio y costo por clic.",
    },
    {
      title: "Meta Ads (Facebook + Instagram)",
      description:
        "Llega a tus clientes ideales en Facebook e Instagram. Anuncios en feed, stories, reels y marketplace. Creatividades que convierten, no solo se ven bonitas.",
    },
    {
      title: "TikTok Ads",
      description:
        "Aprovecha la red social de más rápido crecimiento en LATAM. Anuncios in-feed, spark ads, topview. Ideal para marcas que quieren conectar con audiencias jóvenes.",
    },
    {
      title: "Landing pages optimizadas",
      description:
        "No basta con buenos anuncios. Creamos landing pages que convierten visitantes en leads. A/B testing, copywriting persuasivo, diseño centrado en conversión.",
    },
  ],
  pricingLabel: "📢 Ver paquetes de Ads",
  pricingDetail:
    "Planes desde $1,500,000 COP/mes (incluye gestión + presupuesto en medios). ROI promedio 340% en los primeros 90 días o trabajamos sin costo.",
  faqItems: [
    {
      q: "¿Cuánto debo invertir en publicidad digital?",
      a: "Para PYMES en Colombia recomendamos partir con $1,500,000 COP/mes (gestión + presupuesto en medios). Con eso podemos generar leads cualificados desde la semana 2. A medida que veas resultados, escalamos la inversión. Sin contratos de permanencia.",
    },
    {
      q: "¿En cuánto tiempo veré resultados?",
      a: "Google Ads puede mostrar leads desde la semana 2. Meta Ads típicamente en 3-4 semanas tras optimización. El ROI completo se estabiliza a los 90 días con optimización continua. Cada semana recibes un reporte con métricas reales.",
    },
    {
      q: "¿Qué plataforma es mejor: Google Ads o Meta Ads?",
      a: "Depende de tu negocio. Si vendes productos con intención de búsqueda (ej: 'abogado divorcios Bogotá'), Google Ads. Si vendes productos de consumo o servicios que la gente no busca activamente (ej: cursos, moda), Meta Ads. En la auditoría gratis te recomendamos la mezcla óptima.",
    },
    {
      q: "¿Trabajan con presupuesto pequeño?",
      a: "Sí, trabajamos con PYMES desde $1,500,000 COP/mes. Sabemos que cada peso cuenta. Enfocamos todo en generar leads cualificados, no en gastar por gastar. Si tu presupuesto es menor, te recomendamos empezar con SEO orgánico.",
    },
  ],
};

export default function Page() {
  return <ServicePage data={DATA} />;
}
