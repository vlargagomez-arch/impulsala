import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { headers } from "next/headers";
import { CrmApp } from "@/components/crm/app";
import { CrmLogin } from "@/components/crm/login";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "CRM | Trackela",
  robots: { index: false, follow: false },
};

export default async function CrmPage(req: NextRequest) {
  let userEmail: string | null = null;

  // 1. Intentar NextAuth
  try {
    const session = await getServerSession(authOptions);
    if (session?.user?.email) {
      userEmail = session.user.email;
    }
  } catch (e) {
    // BD falla, continuar
  }

  // 2. Fallback: leer cookie nexus-admin-session de headers
  if (!userEmail) {
    try {
      const headersList = await headers();
      const cookieHeader = headersList.get("cookie") || "";
      const match = cookieHeader.match(/nexus-admin-session=([^;]+)/);
      if (match) {
        const cookieValue = decodeURIComponent(match[1]);
        const decoded = Buffer.from(cookieValue, "base64").toString();
        const [email] = decoded.split(":");
        if (email === "admin@trackela.co") {
          userEmail = email;
        }
      }
    } catch (e) {
      // ignore
    }
  }

  // 3. Fallback: leer cookie de req.cookies
  if (!userEmail && req?.cookies) {
    const simpleSession = req.cookies.get("nexus-admin-session");
    if (simpleSession) {
      try {
        const decoded = Buffer.from(simpleSession, "base64").toString();
        const [email] = decoded.split(":");
        if (email === "admin@trackela.co") {
          userEmail = email;
        }
      } catch {
        // ignore
      }
    }
  }

  if (!userEmail) {
    return <CrmLogin />;
  }

  return <CrmApp userEmail={userEmail} />;
}
