# Trackela - Agencia Web + CRM + IA
## 🚀 Deploy rápido a Vercel (30 min)
Lee `deploy-kit/PROMPT-PARA-IA.md` y pégalo en Hermes, Claude, o cualquier IA.
## Credenciales CRM
- Email: admin@trackela.co
- Password: nexus2026
