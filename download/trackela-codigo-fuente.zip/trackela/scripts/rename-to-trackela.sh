#!/bin/bash
# Cambia Trackela → Trackela en todo el proyecto
# Mantiene la estructura, solo cambia el nombre

set -e

cd /home/z/my-project

echo "📝 Cambiando Trackela → Trackela en todos los archivos..."
echo ""

# Lista de archivos a procesar (excluyendo node_modules, .next, etc.)
FILES=$(find . \
  -type f \
  -not -path "./node_modules/*" \
  -not -path "./.next/*" \
  -not -path "./.git/*" \
  -not -path "./upload/*" \
  -not -path "./tool-results/*" \
  -not -path "./download/*" \
  -not -name "*.log" \
  -not -name "*.zip" \
  -not -name "*.db" \
  -not -name "*.db.backup" \
  -not -name "google-token.json" \
  \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.json" -o -name "*.md" -o -name "*.sh" -o -name "*.env*" -o -name "*.yml" -o -name "*.yaml" -o -name "*.prisma" -o -name "*.css" -o -name "*.html" -o -name "Caddyfile" \) \
  2>/dev/null)

count=0
for file in $FILES; do
  if grep -q "Trackela\|trackela\|trackela\|TRACKEЛА\|trackela\|Trackela" "$file" 2>/dev/null; then
    # Trackela → Trackela
    sed -i 's/Trackela/Trackela/g' "$file"
    # trackela → trackela
    sed -i 's/trackela/trackela/g' "$file"
    # TRACKEЛА → TRACKEЛА
    sed -i 's/TRACKEЛА/TRACKEЛА/g' "$file"
    # trackela → trackela
    sed -i 's/trackela/trackela/g' "$file"
    # "Trackela" → "Trackela"
    sed -i 's/Trackela/Trackela/g' "$file"
    # trackela → trackela
    sed -i 's/trackela/trackela/g' "$file"
    # TrackelaBot / trackelabot → TrackelaBot / trackelabot
    sed -i 's/TrackelaBot/TrackelaBot/g' "$file"
    sed -i 's/trackelabot/trackelabot/g' "$file"
    count=$((count + 1))
    echo "  ✓ $file"
  fi
done

echo ""
echo "✅ $count archivos actualizados"
echo ""

# Casos especiales - nombres de paquete
echo "📝 Actualizando package.json..."
if [ -f "package.json" ]; then
  sed -i 's/"name": "nextjs_tailwind_shadcn_ts"/"name": "trackela"/' package.json
  echo "  ✓ package.json"
fi

# Actualizar .env
echo "📝 Actualizando .env..."
if [ -f ".env" ]; then
  # Mantener credenciales pero cambiar nombres
  sed -i 's/admin@trackela.co/admin@trackela.co/g' .env
  sed -i 's/contacto@trackela.co/contacto@trackela.co/g' .env
  sed -i 's|https://trackela.co|https://trackela.co|g' .env
  echo "  ✓ .env"
fi

echo ""
echo "🎉 Cambio completado!"
echo ""
echo "Verificando cambios..."
remaining=$(grep -rl "Trackela\|trackela" src/ 2>/dev/null | wc -l)
echo "Apariciones restantes en src/: $remaining"
