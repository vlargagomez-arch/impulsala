# NexusDigital - Agencia Web + CRM + IA

## 🚀 Deploy rápido a Vercel (30 min)

Lee `deploy-kit/PROMPT-PARA-IA.md` y pégalo en Hermes, Claude, o cualquier IA.
El asistente IA hará toda la migración automáticamente.

O lee `deploy-kit/README-VERCEL.md` para hacerlo manualmente paso a paso.

## Instalación local

```bash
bun install
cp .env.example .env  # Editar con tus credenciales
bunx prisma generate
bunx prisma db push
bun run dev
```

## Características
- Next.js 16 + App Router
- CRM (citas, leads, newsletter, campañas)
- Chatbot IA para agendamiento
- Gmail integration
- Google Calendar + Meet automático
- WhatsApp recordatorios manuales
- SEO técnico completo
- Blog con 25+ artículos
- Tailwind CSS 4 + shadcn/ui

## Credenciales CRM
- Email: admin@nexusdigital.co
- Password: nexus2026
