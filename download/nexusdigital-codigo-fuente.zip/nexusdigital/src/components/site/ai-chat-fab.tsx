"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { Send, Bot, User, Sparkles, Zap, TrendingUp, Clock, CheckCircle2, Calendar, User2, Mail, Phone, Building2, Loader2, X, MessageSquare } from "lucide-react";

/* ============================================================
   TIPOS
   ============================================================ */
type MsgRole = "bot" | "user";

type Metric = { label: string; value: string };
type ListBlock = { title: string; items: string[] };

type Msg = {
  role: MsgRole;
  text: string;
  metrics?: Metric[];
  list?: ListBlock[];
  suggestions?: string[];
  formField?: FormField;
  bookingConfirmation?: BookingData;
  bookingReview?: BookingData;
  showBackToStart?: boolean;
};

type FormField = {
  field: "name" | "email" | "phone" | "hasBusiness" | "datetime" | "consent" | null;
  label: string;
  placeholder: string;
  icon: "user" | "mail" | "phone" | "building";
  inputType: "text" | "email" | "tel" | "select" | "datetime" | "consent";
  options?: string[];
};

type BookingData = {
  name: string;
  email: string;
  phone: string;
  hasBusiness: string;
  datetime?: string;
  consent?: string;
  service?: string;
};

type ConversationMode = "general" | "booking" | "diagnostic";

/* ============================================================
   RESPUESTAS PREDEFINIDAS
   ============================================================ */
const QUICK_PROMPTS = [
  "¿Qué servicios ofrecen?",
  "¿Cuánto cuesta?",
  "Necesito mejorar mi SEO",
  "Quiero agendar una cita",
];

const RESPONSES: Record<string, Msg> = {
  "¿qué servicios ofrecen?": {
    role: "bot",
    text: "En NexusDigital ofrecemos 4 servicios integrados: desarrollo de software a medida, mejoramiento web + SEO, campañas publicitarias (Google/Meta/TikTok/YouTube Ads) y automatizaciones + IA. Todo pensado para que tu negocio crezca desde el día uno.",
    metrics: [
      { label: "Apps entregadas", value: "40+" },
      { label: "ROI promedio", value: "340%" },
      { label: "Tiempo de respuesta", value: "< 2h" },
    ],
    suggestions: ["¿Cuánto cuesta?", "Necesito mejorar mi SEO", "Quiero agendar una cita"],
  },
  "¿cuánto cuesta?": {
    role: "bot",
    text: "Cada proyecto es único, por eso no vendemos paquetes genéricos. Hacemos un diagnóstico gratuito donde analizamos tus objetivos, presupuesto y timeline, y te entregamos una propuesta a medida. La inversión depende del alcance, pero trabajamos con ROI medible desde el primer mes.",
    metrics: [
      { label: "Diagnóstico", value: "Gratis" },
      { label: "ROI promedio", value: "3.2x" },
      { label: "Contratos forzosos", value: "0" },
    ],
    suggestions: ["Agendar diagnóstico gratis", "Quiero automatizar mi negocio"],
  },
  "necesito mejorar mi seo": {
    role: "bot",
    text: "Nuestro servicio SEO está diseñado para posicionarte en las primeras posiciones de Google con resultados medibles y sostenibles. Trabajamos en 3 pilares: auditoría técnica, optimización on-page y estrategia off-page.",
    metrics: [
      { label: "Posiciones Top 3", value: "78%" },
      { label: "Tráfico orgánico", value: "+210%" },
      { label: "Keywords Top 10", value: "45+" },
    ],
    suggestions: ["Agendar auditoría gratis", "¿Cuánto tiempo toma ver resultados?"],
  },
  "quiero automatizar mi negocio": {
    role: "bot",
    text: "Automatizamos procesos repetitivos y creamos agentes de IA que trabajan 24/7 por ti. Promedio: 120 horas ahorradas al mes por cliente. Implementamos flujos automatizados, chatbots inteligentes, publicación automática en redes y agentes de venta con IA.",
    metrics: [
      { label: "Horas ahorradas", value: "120h/mes" },
      { label: "Operación", value: "24/7" },
      { label: "Implementación", value: "2-4 sem" },
    ],
    suggestions: ["¿Qué servicios ofrecen?", "Quiero agendar una cita"],
  },
  "¿cuánto tiempo toma ver resultados?": {
    role: "bot",
    text: "Depende del servicio: las campañas de Ads pueden mostrar resultados desde la semana 2, el SEO orgánico típicamente entrega mejoras visibles entre 3 y 6 meses, y las automatizaciones empiezan a ahorrar tiempo desde la primera semana de implementación.",
    metrics: [
      { label: "Ads", value: "2-4 sem" },
      { label: "SEO", value: "3-6 mes" },
      { label: "Automatización", value: "1 sem" },
    ],
    suggestions: ["Quiero agendar una cita", "Necesito mejorar mi SEO"],
  },
  default: {
    role: "bot",
    text: "Gracias por tu mensaje. Puedo ayudarte con información sobre nuestros servicios, precios, SEO, automatización con IA, y también puedo agendarte una cita gratuita con nuestro equipo. ¿Qué te gustaría hacer?",
    suggestions: ["¿Qué servicios ofrecen?", "¿Cuánto cuesta?", "Quiero agendar una cita"],
  },
};

const BOOKING_STEPS: FormField[] = [
  { field: "name", label: "¿Cómo te llamas?", placeholder: "Ej: María López", icon: "user", inputType: "text" },
  { field: "email", label: "¿Cuál es tu correo electrónico?", placeholder: "Ej: maria@email.com", icon: "mail", inputType: "email" },
  { field: "phone", label: "¿Cuál es tu número de WhatsApp/teléfono?", placeholder: "Ej: 322 707 2022", icon: "phone", inputType: "tel" },
  {
    field: "hasBusiness",
    label: "¿Tienes un negocio actualmente?",
    placeholder: "Selecciona una opción",
    icon: "building",
    inputType: "select",
    options: ["Sí, tengo un negocio", "Soy emprendedor", "Trabajo en una empresa", "Aún no tengo negocio"],
  },
  {
    field: "datetime",
    label: "¿Qué horario te queda mejor para la videollamada de 30 minutos?",
    placeholder: "Selecciona un horario disponible",
    icon: "building",
    inputType: "datetime",
  },
  {
    field: "consent",
    label: "¿Nos autorizas a enviarte recordatorios por email y WhatsApp sobre tu cita?",
    placeholder: "Selecciona una opción",
    icon: "building",
    inputType: "consent",
    options: ["Sí, autorizo", "Solo WhatsApp", "Solo email", "No, gracias"],
  },
];

const INITIAL_MESSAGE: Msg = {
  role: "bot",
  text: "¡Hola! Soy NexusBot, el asistente de IA de NexusDigital. Puedo ayudarte con información sobre nuestros servicios, precios, SEO, automatización con IA... y también puedo agendarte una cita gratuita. ¿En qué te puedo ayudar?",
  suggestions: QUICK_PROMPTS,
};

function normalize(text: string) {
  return text.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^[\d\s+()\-.]{7,20}$/;

function validateField(field: FormField, value: string): string | null {
  const v = value.trim();
  if (!v) return "Este campo es obligatorio";
  if (field.field === "email" && !EMAIL_RE.test(v)) return "Email inválido. Ej: maria@email.com";
  if (field.field === "phone" && !PHONE_RE.test(v)) return "Teléfono inválido. Ej: 322 707 2022";
  if (field.field === "name" && v.length < 2) return "Tu nombre debe tener al menos 2 caracteres";
  return null;
}

function pickGeneralResponse(input: string): Msg {
  const n = normalize(input);
  for (const key of Object.keys(RESPONSES)) {
    if (key === "default") continue;
    const cleanKey = normalize(key.replace(/[?¿]/g, ""));
    if (n.includes(cleanKey)) return RESPONSES[key];
  }
  if (n.includes("precio") || n.includes("costo") || n.includes("cuesta")) return RESPONSES["¿cuánto cuesta?"];
  if (n.includes("seo") || n.includes("google") || n.includes("posicionar")) return RESPONSES["necesito mejorar mi seo"];
  if (n.includes("automat") || n.includes("bot") || n.includes("ia")) return RESPONSES["quiero automatizar mi negocio"];
  if (n.includes("servicio") || n.includes("ofrecen")) return RESPONSES["¿qué servicios ofrecen?"];
  if (n.includes("tiempo") || n.includes("resultado")) return RESPONSES["¿cuánto tiempo toma ver resultados?"];
  return RESPONSES.default;
}

function wantsToBook(input: string): boolean {
  const n = normalize(input);
  return n.includes("agendar") || n.includes("cita") || n.includes("diagnostico") ||
         n.includes("asesoria") || n.includes("calendario") || n.includes("horario") ||
         n.includes("auditoria gratis") || n.includes("reservar") || n.includes("reunion") ||
         n.includes("videollamada") || n.includes("contactar") || n.includes("llamen");
}

function FormIcon({ icon }: { icon: FormField["icon"] }) {
  if (icon === "user") return <User2 className="h-4 w-4" />;
  if (icon === "mail") return <Mail className="h-4 w-4" />;
  if (icon === "phone") return <Phone className="h-4 w-4" />;
  return <Building2 className="h-4 w-4" />;
}

/* ============================================================
   COMPONENTE PRINCIPAL — Widget flotante NexusBot
   ============================================================ */
export default function AiChatFab() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([INITIAL_MESSAGE]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [mode, setMode] = useState<ConversationMode>("general");
  const [bookingStep, setBookingStep] = useState(0);
  const [bookingData, setBookingData] = useState<Partial<BookingData>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [submittingBooking, setSubmittingBooking] = useState(false);
  const [hasNewMessage, setHasNewMessage] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, typing]);

  // Reset conversación al cerrar
  const handleClose = useCallback(() => {
    setOpen(false);
    setHasNewMessage(true);
  }, []);

  const pushBotMessage = useCallback((msg: Msg, delay = 350) => {
    setTyping(true);
    setTimeout(() => {
      setMessages((prev) => [...prev, msg]);
      setTyping(false);
    }, delay + Math.random() * 150);
  }, []);

  const startBooking = useCallback(() => {
    setMode("booking");
    setBookingStep(0);
    setBookingData({});
    setFormError(null);
    pushBotMessage({
      role: "bot",
      text: "¡Perfecto! Te voy a agendar una cita gratuita de 30 minutos con nuestro equipo. Solo necesito algunos datos para contactarte. Empecemos 👇",
    }, 400);
    setTimeout(() => {
      pushBotMessage({
        role: "bot",
        text: BOOKING_STEPS[0].label,
        formField: BOOKING_STEPS[0],
      }, 600);
    }, 1500);
  }, [pushBotMessage]);

  // Iniciar conversación de diagnóstico (desde el blog)
  const startDiagnostic = useCallback(() => {
    setMode("diagnostic");
    setMessages([]);
    pushBotMessage({
      role: "bot",
      text: "¡Hola! Qué gusto tenerte por aquí 😊 Soy NexusBot, tu asistente en NexusDigital.",
    }, 400);
    setTimeout(() => {
      pushBotMessage({
        role: "bot",
        text: "Veo que quieres un diagnóstico gratis. Para poder ayudarte mejor, cuéntame: ¿Qué necesitas para tu negocio?",
        suggestions: [
          "Desarrollar una página web",
          "Automatización con IA",
          "Campañas publicitarias (Ads)",
          "SEO y posicionamiento",
          "No estoy seguro, ayúdame",
        ],
      }, 600);
    }, 1200);
  }, [pushBotMessage]);

  // Escuchar evento global para abrir el chat (disparado por botones "Agendar")
  useEffect(() => {
    const handleOpen = (e: Event) => {
      const detail = (e as CustomEvent).detail as { startBooking?: boolean; diagnostic?: boolean } | undefined;
      setOpen(true);
      setHasNewMessage(false);
      if (detail?.startBooking) {
        setTimeout(() => startBooking(), 600);
      } else if (detail?.diagnostic) {
        setTimeout(() => startDiagnostic(), 600);
      }
    };
    window.addEventListener("open-ai-chat", handleOpen as EventListener);
    return () => window.removeEventListener("open-ai-chat", handleOpen as EventListener);
  }, [startBooking, startDiagnostic]);

  const processBookingField = useCallback(async (value: string) => {
    const currentField = BOOKING_STEPS[bookingStep];
    if (!currentField.field) return;

    const error = validateField(currentField, value);
    if (error) {
      setFormError(error);
      return;
    }
    setFormError(null);

    const newData = { ...bookingData, [currentField.field]: value.trim() };
    setBookingData(newData);

    const nextStep = bookingStep + 1;
    setBookingStep(nextStep);

    if (nextStep < BOOKING_STEPS.length) {
      const nextField = BOOKING_STEPS[nextStep];
      pushBotMessage({
        role: "bot",
        text: `¡Gracias ${currentField.field === "name" ? value.trim() : ""}! ${nextField.label}`,
        formField: nextField,
      }, 500);
    } else {
      const finalData: BookingData = {
        name: newData.name || "",
        email: newData.email || "",
        phone: newData.phone || "",
        hasBusiness: newData.hasBusiness || "",
        datetime: newData.datetime || "",
        consent: newData.consent || "",
      };
      // Mostrar resumen para confirmación (NO agendar aún)
      const fechaCita = finalData.datetime
        ? new Date(finalData.datetime).toLocaleString("es-CO", {
            weekday: "long",
            day: "numeric",
            month: "long",
            hour: "2-digit",
            minute: "2-digit",
          })
        : "próximamente";

      pushBotMessage({
        role: "bot",
        text: `¡Perfecto ${finalData.name}! Revisa que tus datos estén correctos y confirma tu cita para ${fechaCita}:`,
        bookingReview: finalData,
      }, 500);
    }
  }, [bookingStep, bookingData, pushBotMessage]);

  // Confirmar la cita después de la revisión
  const confirmBooking = useCallback(async (data: BookingData) => {
    setSubmittingBooking(true);
    setMessages((prev) => [...prev, { role: "user", text: "✅ Confirmar cita" }]);
    pushBotMessage({
      role: "bot",
      text: "¡Perfecto! Estoy guardando tus datos y agendando tu cita...",
    }, 400);

    try {
      const apptRes = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: data.name,
          business: data.hasBusiness,
          hasWebsite: "no",
          email: data.email,
          phone: data.phone,
          scheduledAt: data.datetime,
        }),
      });

      await fetch("/api/booking-leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: data.name,
          email: data.email,
          phone: data.phone,
          hasBusiness: data.hasBusiness,
          source: "ai-chat",
        }),
      });

      const result = await apptRes.json();
      setSubmittingBooking(false);
      setMode("general");

      if (apptRes.ok) {
        const fechaCita = data.datetime
          ? new Date(data.datetime).toLocaleString("es-CO", {
              weekday: "long",
              day: "numeric",
              month: "long",
              hour: "2-digit",
              minute: "2-digit",
            })
          : "próximamente";

        // Mostrar confirmación con link de Meet generado automáticamente
        const meetLink = result.meetLink || "";
        const meetText = meetLink
          ? `\n\n📹 Link de videollamada:\n${meetLink}\n\nGuarda este link, lo usarás el día de la cita.`
          : "";

        setMessages((prev) => [...prev, {
          role: "bot",
          text: `¡Cita confirmada! 🎉

Tu cita gratuita ha sido agendada para ${fechaCita} (30 minutos).${meetText}

Te enviaremos un correo a ${data.email} con todos los detalles. También puedes confirmar por WhatsApp al 322 707 2022.`,
          bookingConfirmation: { ...data, meetLink },
          suggestions: ["¿Qué servicios ofrecen?", "¿Cuánto cuesta?"],
          showBackToStart: true,
        }]);

        // Mensaje de seguimiento
        setTimeout(() => {
          pushBotMessage({
            role: "bot",
            text: `📞 Nos vemos pronto en la videollamada. Si tienes dudas antes de la cita, escríbenos al 322 707 2022.`,
          }, 800);
        }, 2000);
      } else {
        setMessages((prev) => [...prev, {
          role: "bot",
          text: `Hubo un problema agendando tu cita (${result.error || "error desconocido"}). Por favor escríbenos directamente por WhatsApp al 322 707 2022.`,
          suggestions: ["Quiero agendar una cita", "¿Qué servicios ofrecen?"],
        }]);
      }
    } catch (err) {
      setSubmittingBooking(false);
      setMode("general");
      setMessages((prev) => [...prev, {
        role: "bot",
        text: "No pude conectar con el servidor. Por favor escríbenos directamente por WhatsApp al 322 707 2022 para agendar tu cita.",
        suggestions: ["Quiero agendar una cita", "¿Qué servicios ofrecen?"],
      }]);
    }
  }, [pushBotMessage]);

  // Editar los datos — reinicia el flujo desde el principio
  const editBooking = useCallback(() => {
    setMessages((prev) => [...prev, { role: "user", text: "✏️ Editar datos" }]);
    setMode("general");
    setBookingStep(0);
    setBookingData({});
    setFormError(null);
    pushBotMessage({
      role: "bot",
      text: "¡Claro! Vamos a editar tus datos. Empecemos de nuevo 👇",
    }, 400);
    setTimeout(() => {
      pushBotMessage({
        role: "bot",
        text: BOOKING_STEPS[0].label,
        formField: BOOKING_STEPS[0],
      }, 600);
    }, 1200);
  }, [pushBotMessage]);

  // Volver al inicio — reinicia la conversación al mensaje inicial
  const backToStart = useCallback(() => {
    setMessages((prev) => [...prev, { role: "user", text: "🏠 Volver al inicio" }]);
    setMode("general");
    setBookingStep(0);
    setBookingData({});
    setFormError(null);
    setTimeout(() => {
      setMessages([INITIAL_MESSAGE]);
    }, 400);
  }, []);

  const send = useCallback((text: string) => {
    const trimmed = text.trim();
    if (!trimmed || typing) return;

    if (mode === "booking" && bookingStep < BOOKING_STEPS.length) {
      setInput("");
      setMessages((prev) => [...prev, { role: "user", text: trimmed }]);
      processBookingField(trimmed);
      return;
    }

    setInput("");
    setMessages((prev) => [...prev, { role: "user", text: trimmed }]);

    // Modo diagnóstico — responder según el servicio que le interesa
    if (mode === "diagnostic") {
      setTyping(true);
      setTimeout(() => {
        const n = normalize(trimmed);
        let response: Msg;

        if (n.includes("web") || n.includes("pagina") || n.includes("sitio")) {
          response = {
            role: "bot",
            text: "¡Excelente! Desarrollamos páginas web ultra rápidas con Next.js, optimizadas para Google y diseñadas para convertir visitantes en clientes. Desde $500.000 COP. ¿Quieres que agendemos una videollamata de 30 minutos para revisar tu caso?",
            suggestions: ["Sí, agendar cita gratis", "¿Cuánto cuesta?", "¿Qué servicios ofrecen?"],
          };
        } else if (n.includes("automat") || n.includes("bot") || n.includes("ia")) {
          response = {
            role: "bot",
            text: "¡Perfecto! Implementamos agentes de IA que atienden clientes 24/7, chatbots inteligentes y automatización de procesos. Imagina que tu negocio nunca duerme. ¿Te gustaría agendar una cita para contarnos tu caso?",
            suggestions: ["Sí, agendar cita gratis", "¿Cuánto cuesta?", "¿Qué servicios ofrecen?"],
          };
        } else if (n.includes("ads") || n.includes("publicidad") || n.includes("google") || n.includes("meta") || n.includes("instagram") || n.includes("tiktok")) {
          response = {
            role: "bot",
            text: "¡Genial! Manejamos campañas en Google Ads, Meta Ads (Facebook/Instagram) y TikTok Ads. Reducimos tu costo por lead y aumentamos tus ventas. ¿Agendamos una videollamata para tu estrategia?",
            suggestions: ["Sí, agendar cita gratis", "¿Cuánto cuesta?", "¿Qué servicios ofrecen?"],
          };
        } else if (n.includes("seo") || n.includes("posicion") || n.includes("google")) {
          response = {
            role: "bot",
            text: "¡Excelente! Nuestro SEO orgánico muestra resultados en 1-2 meses. Te posicionamos en los primeros resultados de Google. ¿Quieres agendar una cita para auditar tu web?",
            suggestions: ["Sí, agendar cita gratis", "¿Cuánto cuesta?", "¿Qué servicios ofrecen?"],
          };
        } else if (n.includes("no estoy seguro") || n.includes("ayuda") || n.includes("no se")) {
          response = {
            role: "bot",
            text: "¡No te preocupes! Para eso estoy aquí. Cuéntame un poco sobre tu negocio: ¿Qué vendes? ¿Tienes página web? ¿Cómo consigues clientes actualmente?",
            suggestions: ["Tengo un negocio físico", "Vendo online", "No tengo web aún"],
          };
        } else {
          response = {
            role: "bot",
            text: "¡Entendido! Lo que necesitas suena muy interesante. Te recomiendo agendar una videollamata gratuita de 30 minutos con nuestro equipo. Ahí podemos revisar tu caso en detalle y darte una propuesta personalizada. ¿Te animas?",
            suggestions: ["Sí, agendar cita gratis", "¿Cuánto cuesta?", "¿Qué servicios ofrecen?"],
          };
        }
        setMessages((prev) => [...prev, response]);
        setTyping(false);
      }, 400 + Math.random() * 200);
      return;
    }

    if (wantsToBook(trimmed)) {
      setTyping(true);
      setTimeout(() => {
        setMessages((prev) => [...prev, {
          role: "bot",
          text: "¡Excelente! Te puedo agendar una cita gratuita de 30 minutos con nuestro equipo. Voy a pedirte algunos datos para contactarte. ¿Comenzamos?",
          suggestions: ["Sí, agendar mi cita", "Antes cuéntame de los servicios"],
        }]);
        setTyping(false);
      }, 350 + Math.random() * 150);
      return;
    }

    setTyping(true);
    setTimeout(() => {
      const reply = pickGeneralResponse(trimmed);
      setMessages((prev) => [...prev, reply]);
      setTyping(false);
    }, 300 + Math.random() * 200);
  }, [typing, mode, bookingStep, processBookingField]);

  const handleSuggestion = useCallback((suggestion: string) => {
    const n = normalize(suggestion);

    // En modo diagnóstico, procesar sugerencias de servicio
    if (mode === "diagnostic") {
      if (n.includes("agendar") || n.includes("cita")) {
        setMessages((prev) => [...prev, { role: "user", text: suggestion }]);
        startBooking();
        return;
      }
      if (n.includes("cuanto cuesta") || n.includes("precio")) {
        setMessages((prev) => [...prev, { role: "user", text: suggestion }]);
        pushBotMessage(RESPONSES["¿cuánto cuesta?"], 400);
        return;
      }
      if (n.includes("servicios")) {
        setMessages((prev) => [...prev, { role: "user", text: suggestion }]);
        setMode("general");
        pushBotMessage(RESPONSES["¿qué servicios ofrecen?"], 400);
        return;
      }
      // Sugerencias de servicio del diagnóstico
      send(suggestion);
      return;
    }

    if (n.includes("agendar mi cita") || n.includes("auditoria gratis") || n.includes("diagnostico gratis")) {
      setMessages((prev) => [...prev, { role: "user", text: suggestion }]);
      startBooking();
      return;
    }
    if (n.includes("antes cuentame") || n.includes("servicios")) {
      setMessages((prev) => [...prev, { role: "user", text: suggestion }]);
      setMode("general");
      pushBotMessage(RESPONSES["¿qué servicios ofrecen?"], 400);
      return;
    }
    send(suggestion);
  }, [send, startBooking, pushBotMessage, mode]);

  function renderAvatar(role: MsgRole) {
    if (role === "user") {
      return (
        <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-secondary text-foreground">
          <User className="h-3.5 w-3.5" />
        </div>
      );
    }
    return (
      <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-sky-500 text-white">
        <Bot className="h-3.5 w-3.5" />
      </div>
    );
  }

  const currentField = mode === "booking" && bookingStep < BOOKING_STEPS.length ? BOOKING_STEPS[bookingStep] : null;
  const showFormInput = currentField && !submittingBooking;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col items-end gap-2">
      {/* Overlay mobile */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={handleClose}
          aria-hidden="true"
        />
      )}

      {/* Panel del chat flotante */}
      {open && (
        <div
          className="fixed inset-x-2 bottom-2 top-12 z-50 flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl
                     lg:static lg:inset-auto lg:bottom-auto lg:top-auto lg:w-[420px]"
          style={{ maxHeight: "calc(100vh - 2rem)" }}
        >
          {/* Header con gradiente NexusDigital */}
          <div className="flex flex-shrink-0 items-center gap-3 p-3 bg-gradient-to-r from-violet-600 to-sky-600">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-white/20">
              <Bot className="h-5 w-5 text-white" />
              <span className="absolute -bottom-0.5 -right-0.5 flex h-3 w-3 items-center justify-center rounded-full border-2 border-violet-600 bg-emerald-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white truncate">NexusBot · Asistente IA</p>
              <p className="text-xs text-white/80 truncate flex items-center gap-1">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-300 animate-pulse" />
                En línea · Agenda tu cita gratis
              </p>
            </div>
            <button
              onClick={handleClose}
              aria-label="Cerrar"
              className="size-7 rounded-full flex items-center justify-center hover:bg-white/15 transition-colors text-white"
            >
              <X className="size-4" />
            </button>
          </div>

          {/* Mensajes */}
          <div ref={scrollRef} className="scrollbar-thin flex-1 min-h-0 space-y-3 overflow-y-auto px-3 py-3 sm:px-4 bg-background/40">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"} ai-chat-fade-in`}>
                <div className={`flex max-w-[90%] gap-2 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
                  {renderAvatar(m.role)}
                  <div className="space-y-2 min-w-0">
                    <div className={`rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${m.role === "user" ? "bg-gradient-to-br from-violet-600 to-sky-600 text-white" : "bg-secondary/60 text-foreground"}`}>
                      {m.text}
                    </div>

                    {m.metrics && (
                      <div className="grid grid-cols-3 gap-1.5">
                        {m.metrics.map((metric) => (
                          <div key={metric.label} className="rounded-lg border border-border/60 bg-background/60 px-1.5 py-1.5 text-center">
                            <div className="text-xs font-bold text-gradient-primary">{metric.value}</div>
                            <div className="text-[9px] text-muted-foreground leading-tight">{metric.label}</div>
                          </div>
                        ))}
                      </div>
                    )}

                    {m.list && (
                      <div className="space-y-1.5">
                        {m.list.map((block) => (
                          <div key={block.title} className="rounded-lg border border-border/60 bg-background/60 px-3 py-2">
                            <div className="mb-1 text-xs font-semibold text-primary">{block.title}</div>
                            <ul className="space-y-0.5">
                              {block.items.map((it) => (
                                <li key={it} className="flex items-start gap-1.5 text-xs text-muted-foreground">
                                  <span className="mt-1 h-1 w-1 flex-shrink-0 rounded-full bg-primary" />
                                  {it}
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    )}

                    {m.bookingConfirmation && <BookingConfirmationCard data={m.bookingConfirmation} />}
                    {m.bookingReview && (
                      <BookingReviewCard
                        data={m.bookingReview}
                        onConfirm={() => confirmBooking(m.bookingReview!)}
                        onEdit={editBooking}
                        disabled={typing || submittingBooking}
                      />
                    )}

                    {m.suggestions && m.suggestions.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {m.suggestions.map((sug) => (
                          <button
                            key={sug}
                            onClick={() => handleSuggestion(sug)}
                            disabled={typing || submittingBooking}
                            className="rounded-full border border-border/60 bg-secondary/40 px-2.5 py-1 text-xs text-foreground/90 transition-colors hover:border-primary/40 hover:bg-primary/10 disabled:opacity-50"
                          >
                            {sug}
                          </button>
                        ))}
                      </div>
                    )}

                    {m.showBackToStart && (
                      <button
                        onClick={backToStart}
                        disabled={typing || submittingBooking}
                        className="flex items-center justify-center gap-1.5 rounded-lg border border-primary/40 bg-primary/10 px-3 py-2 text-xs font-semibold text-primary transition-colors hover:bg-primary/20 disabled:opacity-50"
                      >
                        🏠 Volver al inicio
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {typing && (
              <div className="flex justify-start ai-chat-fade-in">
                <div className="flex items-center gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-sky-500 text-white">
                    <Bot className="h-3.5 w-3.5" />
                  </div>
                  <div className="flex items-center gap-1 rounded-2xl bg-secondary/60 px-3.5 py-3">
                    {[0, 1, 2].map((i) => (
                      <span key={i} className="h-1.5 w-1.5 rounded-full bg-foreground/60 animate-typing" style={{ animationDelay: `${i * 0.15}s` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {submittingBooking && (
              <div className="flex justify-start ai-chat-fade-in">
                <div className="flex items-center gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-sky-500 text-white">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  </div>
                  <div className="rounded-2xl bg-secondary/60 px-3.5 py-2.5 text-sm text-muted-foreground">
                    Guardando tu cita...
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="flex-shrink-0 border-t border-border/60 bg-secondary/20 px-3 py-2.5 sm:px-4">
            {showFormInput && currentField ? (
              <div className="space-y-2">
                {formError && (
                  <p className="text-xs text-red-500 dark:text-red-400">{formError}</p>
                )}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (currentField.inputType === "select" || currentField.inputType === "consent") return;
                    send(input);
                  }}
                  className="flex items-center gap-2"
                >
                  <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
                    <FormIcon icon={currentField.icon} />
                  </div>
                  <input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={currentField.placeholder}
                    type={currentField.inputType === "tel" ? "tel" : currentField.inputType === "email" ? "email" : "text"}
                    autoFocus
                    className="flex-1 rounded-lg border border-border/60 bg-background/60 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                  <button
                    type="submit"
                    disabled={!input.trim() || typing}
                    className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-sky-600 text-white transition-colors hover:opacity-90 disabled:opacity-50"
                    aria-label="Enviar"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </form>
                {currentField.inputType === "select" && currentField.options && (
                  <div className="flex flex-wrap gap-1.5 pl-11">
                    {currentField.options.map((opt) => (
                      <button
                        key={opt}
                        onClick={() => {
                          setMessages((prev) => [...prev, { role: "user", text: opt }]);
                          processBookingField(opt);
                        }}
                        disabled={typing || submittingBooking}
                        className="rounded-full border border-border/60 bg-secondary/40 px-2.5 py-1.5 text-xs text-foreground/90 transition-colors hover:border-primary/40 hover:bg-primary/10 disabled:opacity-50"
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                )}
                {currentField.inputType === "datetime" && (
                  <DateTimePicker
                    onSelect={(label, isoDate) => {
                      setMessages((prev) => [...prev, { role: "user", text: label }]);
                      processBookingField(isoDate);
                    }}
                    disabled={typing || submittingBooking}
                  />
                )}
                {currentField.inputType === "consent" && currentField.options && (
                  <div className="flex flex-wrap gap-1.5 pl-11">
                    {currentField.options.map((opt) => (
                      <button
                        key={opt}
                        onClick={() => {
                          setMessages((prev) => [...prev, { role: "user", text: opt }]);
                          processBookingField(opt);
                        }}
                        disabled={typing || submittingBooking}
                        className={`rounded-full border px-2.5 py-1.5 text-xs text-foreground/90 transition-colors hover:border-primary/40 hover:bg-primary/10 disabled:opacity-50 ${
                          opt.includes("Sí") || opt.includes("autorizo") ? "border-emerald-500/30 bg-emerald-500/10" : "border-border/60 bg-secondary/40"
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <form
                onSubmit={(e) => { e.preventDefault(); send(input); }}
                className="flex items-center gap-2"
              >
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Escribe tu mensaje..."
                  className="flex-1 rounded-lg border border-border/60 bg-background/60 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || typing || submittingBooking}
                  className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-sky-600 text-white transition-colors hover:opacity-90 disabled:opacity-50"
                  aria-label="Enviar"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            )}
            <p className="mt-1.5 text-center text-[10px] text-muted-foreground">
              NexusBot v2.0 · Agenda citas y responde dudas 24/7
            </p>
          </div>
        </div>
      )}

      {/* FAB — Botón flotante del Agente IA */}
      <button
        onClick={() => { setOpen((v) => !v); setHasNewMessage(false); }}
        aria-label={open ? "Cerrar asistente" : "Abrir asistente NexusBot"}
        className="relative size-14 rounded-full shadow-2xl flex items-center justify-center text-white transition-transform hover:scale-105 bg-gradient-to-br from-violet-600 to-sky-600"
      >
        {open ? (
          <X className="size-6" />
        ) : (
          <>
            {/* Pulsing ring */}
            <span className="absolute inset-0 rounded-full animate-ping opacity-30 bg-violet-500" />
            {/* Badge de nuevo mensaje */}
            {hasNewMessage && (
              <span
                className="absolute -top-0.5 -right-0.5 size-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                style={{ background: "#ef4444", boxShadow: "0 0 0 2px var(--background)" }}
              >
                1
              </span>
            )}
            <MessageSquare className="size-6" fill="currentColor" />
          </>
        )}
      </button>
    </div>
  );
}

/* ============================================================
   SELECTOR DE HORARIOS DISPONIBLES
   ============================================================ */
function DateTimePicker({
  onSelect,
  disabled,
}: {
  onSelect: (label: string, isoDate: string) => void;
  disabled?: boolean;
}) {
  const [dates, setDates] = useState<{ date: string; label: string; weekday: string; slots: { startUtc: string; label: string }[] }[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/appointments/slots?days=14")
      .then((r) => r.json())
      .then((data) => {
        setDates(data.dates || []);
        // Seleccionar el primer día con slots por defecto
        if (data.dates && data.dates.length > 0) {
          setSelectedDate(data.dates[0].date);
        }
        setLoading(false);
      })
      .catch(() => {
        setError("No pude cargar los horarios. Intenta de nuevo.");
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-3 pl-11 text-xs text-muted-foreground">
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
        Cargando horarios disponibles...
      </div>
    );
  }

  if (error) {
    return <p className="pl-11 text-xs text-red-500">{error}</p>;
  }

  if (dates.length === 0) {
    return (
      <p className="pl-11 text-xs text-muted-foreground">
        No hay horarios disponibles en los próximos 14 días. Escríbenos por WhatsApp al 322 707 2022.
      </p>
    );
  }

  const currentDate = dates.find((d) => d.date === selectedDate);

  return (
    <div className="space-y-2">
      {/* Días disponibles — scrollable horizontal */}
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {dates.map((d) => (
          <button
            key={d.date}
            onClick={() => setSelectedDate(d.date)}
            disabled={disabled}
            className={`flex flex-shrink-0 flex-col items-center rounded-lg border px-2.5 py-1.5 text-center transition-colors ${
              selectedDate === d.date
                ? "border-primary bg-primary/15 text-foreground"
                : "border-border/60 bg-secondary/40 text-muted-foreground hover:border-primary/40"
            } disabled:opacity-50`}
          >
            <span className="text-[10px] font-medium uppercase">{d.weekday}</span>
            <span className="text-xs font-bold">{d.label.split(" ")[1]}</span>
          </button>
        ))}
      </div>

      {/* Horarios del día seleccionado — grid scrollear vertical */}
      {currentDate && (
        <div className="max-h-32 overflow-y-auto rounded-lg bg-background/40 p-2">
          <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-4">
            {currentDate.slots.map((slot) => (
              <button
                key={slot.startUtc}
                onClick={() => {
                  const dateLabel = `${currentDate.label} a las ${slot.label}`;
                  onSelect(dateLabel, slot.startUtc);
                }}
                disabled={disabled}
                className="rounded-md border border-border/60 bg-secondary/40 px-1.5 py-1.5 text-[11px] font-medium text-foreground/90 transition-colors hover:border-primary/40 hover:bg-primary/10 disabled:opacity-50"
              >
                {slot.label}
              </button>
            ))}
          </div>
        </div>
      )}
      <p className="text-[10px] text-muted-foreground">
        📅 Lunes a Viernes, 8:00 a. m. - 6:00 p. m. (Hora Colombia)
      </p>
    </div>
  );
}

/* ============================================================
   TARJETA DE REVISIÓN — Confirmar o Editar
   ============================================================ */
function BookingReviewCard({
  data,
  onConfirm,
  onEdit,
  disabled,
}: {
  data: BookingData;
  onConfirm: () => void;
  onEdit: () => void;
  disabled?: boolean;
}) {
  const fechaFormateada = data.datetime
    ? new Date(data.datetime).toLocaleString("es-CO", {
        weekday: "long",
        day: "numeric",
        month: "long",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "próximamente";

  const rows = [
    { icon: User2, label: "Nombre", value: data.name },
    { icon: Mail, label: "Email", value: data.email },
    { icon: Phone, label: "Teléfono", value: data.phone },
    { icon: Building2, label: "Negocio", value: data.hasBusiness },
    ...(data.consent ? [{ icon: CheckCircle2, label: "Contacto", value: data.consent }] : []),
  ];

  return (
    <div className="rounded-xl border-2 border-violet-400/40 bg-violet-400/5 overflow-hidden">
      <div className="flex items-center gap-2 bg-violet-400/10 px-3 py-2 border-b border-violet-400/20">
        <CheckCircle2 className="h-4 w-4 text-violet-500 dark:text-violet-400" />
        <span className="text-xs font-bold text-violet-600 dark:text-violet-400">REVISIÓN DE DATOS</span>
      </div>
      <div className="p-2.5 space-y-1.5">
        {rows.map((row) => (
          <div key={row.label} className="flex items-center gap-2 text-xs">
            <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md bg-secondary/60 text-foreground/70">
              <row.icon className="h-3 w-3" />
            </div>
            <span className="text-muted-foreground w-16 flex-shrink-0">{row.label}:</span>
            <span className="font-semibold text-foreground truncate">{row.value}</span>
          </div>
        ))}
        <div className="flex items-center gap-2 text-xs pt-1.5 border-t border-border/40 mt-1.5">
          <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md bg-primary/15 text-primary">
            <Calendar className="h-3 w-3" />
          </div>
          <span className="text-muted-foreground w-16 flex-shrink-0">Cita:</span>
          <span className="font-semibold text-foreground capitalize">{fechaFormateada}</span>
        </div>
      </div>

      {/* Botones de confirmación */}
      <div className="flex gap-2 border-t border-border/40 p-2.5">
        <button
          onClick={onConfirm}
          disabled={disabled}
          className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 px-3 py-2 text-xs font-semibold text-white transition-all hover:brightness-110 active:scale-95 disabled:opacity-50"
        >
          <CheckCircle2 className="h-3.5 w-3.5" />
          Confirmar cita
        </button>
        <button
          onClick={onEdit}
          disabled={disabled}
          className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-border/60 bg-secondary/40 px-3 py-2 text-xs font-semibold text-foreground transition-colors hover:bg-secondary/60 disabled:opacity-50"
        >
          ✏️ Editar
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   TARJETA DE CONFIRMACIÓN DE AGENDAMIENTO
   ============================================================ */
function BookingConfirmationCard({ data }: { data: BookingData }) {
  const fechaFormateada = data.datetime
    ? new Date(data.datetime).toLocaleString("es-CO", {
        weekday: "long",
        day: "numeric",
        month: "long",
        hour: "2-digit",
        minute: "2-digit",
      })
    : null;

  const rows = [
    { icon: User2, label: "Nombre", value: data.name },
    { icon: Mail, label: "Email", value: data.email },
    { icon: Phone, label: "Teléfono", value: data.phone },
    { icon: Building2, label: "Negocio", value: data.hasBusiness },
    ...(data.consent ? [{ icon: CheckCircle2, label: "Contacto", value: data.consent }] : []),
  ];

  return (
    <div className="rounded-xl border-2 border-emerald-400/30 bg-emerald-400/5 overflow-hidden">
      <div className="flex items-center gap-2 bg-emerald-400/10 px-3 py-2 border-b border-emerald-400/20">
        <CheckCircle2 className="h-4 w-4 text-emerald-500 dark:text-emerald-400" />
        <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">CITA AGENDADA — Resumen</span>
      </div>
      <div className="p-2.5 space-y-1.5">
        {rows.map((row) => (
          <div key={row.label} className="flex items-center gap-2 text-xs">
            <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md bg-secondary/60 text-foreground/70">
              <row.icon className="h-3 w-3" />
            </div>
            <span className="text-muted-foreground w-16 flex-shrink-0">{row.label}:</span>
            <span className="font-semibold text-foreground truncate">{row.value}</span>
          </div>
        ))}
        {fechaFormateada && (
          <div className="flex items-center gap-2 text-xs pt-1.5 border-t border-border/40 mt-1.5">
            <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md bg-primary/15 text-primary">
              <Calendar className="h-3 w-3" />
            </div>
            <span className="text-muted-foreground w-16 flex-shrink-0">Cita:</span>
            <span className="font-semibold text-foreground capitalize">{fechaFormateada}</span>
          </div>
        )}
      </div>
    </div>
  );
}
// eof
