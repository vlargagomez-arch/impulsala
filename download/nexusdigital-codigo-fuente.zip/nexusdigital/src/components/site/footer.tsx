"use client";

import { useState } from "react";
import Link from "next/link";
import { Zap, Linkedin, Instagram, Youtube, Twitter, Github, Mail, Phone, MapPin, Send, Loader2, CheckCircle2, Lock } from "lucide-react";
import { LegalModal, type LegalDoc } from "@/components/site/legal-modal";
import { useToast } from "@/hooks/use-toast";

const FOOTER_LINKS = [
  {
    title: "Servicios",
    links: [
      { label: "Desarrollo Web", href: "/servicios/desarrollo-web" },
      { label: "SEO y Posicionamiento", href: "/servicios/seo" },
      { label: "Campañas Publicitarias", href: "/servicios/publicidad-digital" },
      { label: "Automatización con IA", href: "/servicios/automatizacion-ia" },
      { label: "Chatbots Inteligentes", href: "/servicios/automatizacion-ia" },
    ],
  },
  {
    title: "Recursos",
    links: [
      { label: "Blog", href: "/blog" },
      { label: "Casos de Éxito", href: "/demos" },
      { label: "Demos Interactivas", href: "/demos" },
      { label: "Preguntas Frecuentes", href: "/#faq" },
      { label: "Contacto", href: "/contacto" },
    ],
  },
];

const SOCIAL = [
  { icon: Linkedin, label: "LinkedIn", href: "https://linkedin.com/company/nexusdigital" },
  { icon: Instagram, label: "Instagram", href: "https://instagram.com/nexusdigital" },
  { icon: Youtube, label: "YouTube", href: "https://youtube.com/@nexusdigital" },
  { icon: Twitter, label: "Twitter/X", href: "https://twitter.com/nexusdigital" },
  { icon: Github, label: "GitHub", href: "https://github.com/nexusdigital" },
];

type SubscribeState = "idle" | "loading" | "success" | "error";

export function Footer() {
  const [legalDoc, setLegalDoc] = useState<LegalDoc | null>(null);
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [state, setState] = useState<SubscribeState>("idle");

  async function handleSubscribe(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim() || state === "loading") return;

    setState("loading");

    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), source: "footer" }),
      });

      const data = await res.json();

      if (!res.ok) {
        setState("error");
        toast({
          title: "No se pudo suscribir",
          description: data.error || "Intenta de nuevo más tarde.",
          variant: "destructive",
        });
        return;
      }

      setState("success");
      setEmail("");
      toast({
        title: data.alreadySubscribed ? "Ya estabas suscrito" : "¡Suscripción exitosa!",
        description: data.message || "Recibirás estrategias digitales cada semana.",
      });

      // Reset to idle after 4 seconds so the user can subscribe again if needed
      setTimeout(() => setState("idle"), 4000);
    } catch {
      setState("error");
      toast({
        title: "Error de conexión",
        description: "Verifica tu internet e intenta de nuevo.",
        variant: "destructive",
      });
      setTimeout(() => setState("idle"), 3000);
    }
  }

  return (
    <>
      <footer className="relative mt-auto border-t border-border/60 bg-card">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
        {/* Responsive padding: tight on mobile, expanded on desktop */}
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-10 lg:px-8 lg:py-14">
          {/* Same 4-column structure, just becomes 2x2 grid on mobile */}
          <div className="grid grid-cols-2 gap-5 sm:gap-8 lg:grid-cols-4 lg:gap-10">
            {/* Brand — spans 2 cols on mobile for breathing room */}
            <div className="col-span-2 sm:col-span-2 lg:col-span-1">
              <Link href="/" className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 shadow-lg shadow-indigo-500/20">
                  <Zap className="h-5 w-5 text-white" fill="white" />
                </span>
                <span className="text-base font-extrabold tracking-tight">
                  Nexus<span className="text-gradient-primary">Digital</span>
                </span>
              </Link>
              <p className="mt-3 max-w-xs text-xs leading-relaxed text-muted-foreground sm:mt-4 sm:text-sm">
                Agencia de desarrollo web, SEO y automatización con IA. Transformamos negocios con tecnología de punta.
              </p>
              <div className="mt-4 flex items-center gap-2 sm:mt-5">
                {SOCIAL.map((s) => (
                  <a
                    key={s.label}
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={s.label}
                    className="flex h-8 w-8 items-center justify-center rounded-lg border border-border/60 bg-secondary/30 text-muted-foreground transition-colors hover:border-indigo-500 hover:text-indigo-500 dark:hover:text-indigo-400 sm:h-9 sm:w-9"
                  >
                    <s.icon className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                  </a>
                ))}
              </div>
            </div>

            {/* Link columns */}
            {FOOTER_LINKS.map((col) => (
              <div key={col.title}>
                <h3 className="text-xs font-bold text-foreground uppercase tracking-wider sm:text-sm sm:normal-case sm:tracking-normal">
                  {col.title}
                </h3>
                <ul className="mt-2 space-y-1.5 sm:mt-4 sm:space-y-2.5">
                  {col.links.map((l) => (
                    <li key={l.label}>
                      <Link href={l.href} className="text-xs text-muted-foreground transition-colors hover:text-foreground sm:text-sm">
                        {l.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}

            {/* Contact + Newsletter */}
            <div className="col-span-2 sm:col-span-2 lg:col-span-1">
              <h3 className="text-xs font-bold text-foreground uppercase tracking-wider sm:text-sm sm:normal-case sm:tracking-normal">
                Contacto
              </h3>
              <div className="mt-2 space-y-1.5 text-xs text-muted-foreground sm:mt-4 sm:space-y-2.5 sm:text-sm">
                <a href="mailto:contacto@nexusdigital.co" className="flex items-center gap-2 transition-colors hover:text-foreground">
                  <Mail className="h-3.5 w-3.5 flex-shrink-0 text-indigo-500 dark:text-indigo-400 sm:h-4 sm:w-4" />
                  contacto@nexusdigital.co
                </a>
                <a href="https://wa.me/573227072022" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 transition-colors hover:text-foreground">
                  <Phone className="h-3.5 w-3.5 flex-shrink-0 text-indigo-500 dark:text-indigo-400 sm:h-4 sm:w-4" />
                  322 707 2022
                </a>
                <div className="flex items-start gap-2">
                  <MapPin className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-indigo-500 dark:text-indigo-400 sm:h-4 sm:w-4" />
                  <span>Bogotá, Colombia · Trabajamos en toda LATAM</span>
                </div>
              </div>

              {/* Newsletter */}
              <div className="mt-4 sm:mt-5">
                <p className="text-xs font-semibold text-foreground mb-1">Recibe estrategias digitales</p>
                <p className="text-[10px] text-muted-foreground mb-2">Únete a 2,500+ empresarios. Un email por semana. Cancela cuando quieras.</p>
                <form onSubmit={handleSubscribe} className="flex gap-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="tu@email.com"
                    disabled={state === "loading" || state === "success"}
                    className="flex-1 min-w-0 rounded-lg border border-border/60 bg-input px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:border-indigo-500 focus:outline-none disabled:opacity-60"
                  />
                  <button
                    type="submit"
                    disabled={state === "loading" || state === "success" || !email.trim()}
                    aria-label="Suscribirse"
                    className="flex items-center justify-center rounded-lg bg-gradient-to-r from-indigo-500 to-fuchsia-500 px-3 py-2 text-xs font-medium text-white transition-opacity hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {state === "loading" ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : state === "success" ? (
                      <CheckCircle2 className="h-3.5 w-3.5" />
                    ) : (
                      <Send className="h-3.5 w-3.5" />
                    )}
                  </button>
                </form>
                {state === "success" && (
                  <p className="mt-1.5 text-[10px] text-green-500 dark:text-green-400">
                    ✓ ¡Listo! Revisa tu email.
                  </p>
                )}
                {state === "error" && (
                  <p className="mt-1.5 text-[10px] text-red-500 dark:text-red-400">
                    ✗ No se pudo suscribir. Intenta de nuevo.
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Bottom bar */}
          <div className="mt-6 flex flex-col items-center justify-between gap-3 border-t border-border/60 pt-4 sm:mt-10 sm:flex-row sm:gap-4 sm:pt-6">
            <p className="text-xs text-muted-foreground">
              © {new Date().getFullYear()} NexusDigital. Todos los derechos reservados.
            </p>
            <div className="flex items-center gap-5 text-xs text-muted-foreground">
              <button onClick={() => setLegalDoc("terminos")} className="transition-colors hover:text-foreground">
                Política de Privacidad
              </button>
              <button onClick={() => setLegalDoc("terminos")} className="transition-colors hover:text-foreground">
                Términos de Servicio
              </button>
              <Link
                href="/crm"
                className="flex items-center gap-1 transition-colors hover:text-foreground"
                title="Acceso administrativo"
              >
                <Lock className="w-3 h-3" />
                CRM
              </Link>
            </div>
          </div>
        </div>
      </footer>

      <LegalModal doc={legalDoc} onClose={() => setLegalDoc(null)} />
    </>
  );
}
