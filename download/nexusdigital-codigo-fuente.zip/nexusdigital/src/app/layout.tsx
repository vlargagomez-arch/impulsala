import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/site/theme-provider";
import { StructuredData } from "@/components/site/structured-data";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
  preload: true,
});

// Geist Mono solo se usa en demos (lazy-loaded), no pre-cargar
const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
  preload: false,
});

// URL dinámica: lee de variables de entorno o usa la URL de deployment actual
// En space-z.ai la URL real se pasa en headers x-forwarded-host / x-forwarded-proto
function getSiteUrl(): string {
  // 1. Variable de entorno explícita (prioridad)
  if (process.env.NEXT_PUBLIC_SITE_URL) {
    return process.env.NEXT_PUBLIC_SITE_URL.replace(/\/$/, "");
  }
  // 2. En build estático, usar un default razonable
  //    (se sobreescribe en runtime con headers)
  return "https://d1m686vag521-d.space-z.ai";
}

const SITE_URL = getSiteUrl();
const OG_IMAGE = `${SITE_URL}/og-image.jpg`;

export const metadata: Metadata = {
  title: "NexusDigital | Desarrollo Web, SEO y Automatización con IA | Diagnóstico Gratis",
  description:
    "Rediseñamos tu sitio web, lo posicionamos en Google y automatizamos ventas con IA. Resultados medibles en 30 días o devolución. Agenda diagnóstico gratis en Bogotá, Colombia.",
  keywords: [
    "agencia de desarrollo web",
    "diseño web profesional",
    "SEO para empresas",
    "automatización con IA",
    "marketing digital",
    "desarrollo de software a medida",
    "campañas publicitarias Google Ads",
    "agencia digital",
    "chatbots IA",
    "posicionamiento Google",
  ],
  authors: [{ name: "NexusDigital" }],
  creator: "NexusDigital",
  publisher: "NexusDigital",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: SITE_URL,
  },
  icons: {
    icon: "/logo.svg",
    apple: "/logo.svg",
  },
  openGraph: {
    title: "NexusDigital | Agencia de Desarrollo Web + SEO + IA",
    description:
      "Transforma tu negocio digital con desarrollo web profesional, SEO avanzado y automatización con IA. Diagnóstico gratuito.",
    url: SITE_URL,
    siteName: "NexusDigital",
    images: [
      {
        url: OG_IMAGE,
        width: 1200,
        height: 630,
        alt: "NexusDigital - Agencia de desarrollo web, SEO y automatización con IA",
      },
    ],
    locale: "es_CO",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "NexusDigital | Agencia de Desarrollo Web + SEO + IA",
    description:
      "Transforma tu negocio digital con desarrollo web profesional, SEO avanzado y automatización con IA. Diagnóstico gratuito.",
    images: [OG_IMAGE],
  },
  verification: {
    google: "google-site-verification-code-here",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <head>
        {/* DNS prefetch for remote images */}
        <link rel="dns-prefetch" href="https://sfile.chatglm.cn" />

        {/* Referencia al sitemap.xml — para crawlers */}
        <link rel="sitemap" type="application/xml" href="/sitemap.xml" />

        {/* Prevent flash of wrong theme */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                try {
                  var stored = localStorage.getItem('nexus-theme');
                  var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                  var isDark = stored ? stored === 'dark' : prefersDark;
                  if (isDark) document.documentElement.classList.add('dark');
                } catch(e) {}
              })();
            `,
          }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          storageKey="nexus-theme"
        >
          {children}
          <Toaster />
        </ThemeProvider>
        {/* Schema.org JSON-LD — al final del body para no bloquear el primer paint */}
        <StructuredData />
      </body>
    </html>
  );
}
