import { NextRequest, NextResponse } from "next/server";
import { exchangeCodeForToken } from "@/lib/google-auth";

/**
 * GET /api/google-calendar/callback
 * Google redirige aquí después de que el usuario autoriza.
 * Intercambia el código por un token y lo guarda.
 *
 * En vez de hacer redirect del servidor (que usa 0.0.0.0 en producción),
 * devuelve HTML con JavaScript que redirige al CRM usando window.location
 * que respeta el dominio del navegador.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const code = searchParams.get("code");
  const error = searchParams.get("error");

  let resultMessage = "";
  let resultSuccess = false;
  let resultError = "";

  if (error) {
    resultError = error;
    resultMessage = `Google devolvió un error: ${error}`;
  } else if (!code) {
    resultError = "no_code";
    resultMessage = "No se recibió código de autorización";
  } else {
    const result = await exchangeCodeForToken(code, req);
    if (result.success) {
      resultSuccess = true;
      resultMessage = "✅ Google Calendar conectado exitosamente";
    } else {
      resultError = result.error || "unknown";
      resultMessage = `❌ Error: ${result.error}`;
    }
  }

  // Devolver HTML con JavaScript que redirige al CRM
  // usando window.location que SÍ respeta el dominio del navegador
  const redirectUrl = resultSuccess ? "/crm?google_connected=1" : `/crm?google_error=${encodeURIComponent(resultError)}`;

  const html = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Conectando Google Calendar...</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
      background: #0f172a;
      color: #ffffff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    .container {
      text-align: center;
      padding: 2rem;
    }
    .spinner {
      width: 40px;
      height: 40px;
      border: 4px solid #334155;
      border-top: 4px solid #7c3aed;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto 1rem;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    .message {
      font-size: 1.1rem;
      margin-bottom: 0.5rem;
    }
    .submessage {
      font-size: 0.9rem;
      color: #94a3b8;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="spinner"></div>
    <div class="message">${resultMessage}</div>
    <div class="submessage">Redirigiendo al CRM...</div>
  </div>
  <script>
    // Redirigir al CRM usando window.location que respeta el dominio actual
    setTimeout(function() {
      window.location.href = ${JSON.stringify(redirectUrl)};
    }, 1500);
  </script>
</body>
</html>`;

  return new NextResponse(html, {
    headers: { "Content-Type": "text/html" },
  });
}
