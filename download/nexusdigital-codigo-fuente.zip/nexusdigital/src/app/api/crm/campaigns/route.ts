import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/auth-guard";

// GET — listar todas las campañas
export async function GET(req: NextRequest) {
  const guard = await requireAdmin(req);
  if (!guard.ok) return guard.response;

  const campaigns = await db.emailCampaign.findMany({
    orderBy: { createdAt: "desc" },
  });

  const activeSubs = await db.newsletter.count({ where: { status: "active" } });

  return NextResponse.json({ campaigns, activeSubs });
}

// POST — crear nueva campaña (borrador) o enviarla
export async function POST(req: NextRequest) {
  const guard = await requireAdmin(req);
  if (!guard.ok) return guard.response;

  const body = await req.json();
  const { subject, content, send } = body as { subject: string; content: string; send?: boolean };

  if (!subject || !content) {
    return NextResponse.json({ error: "Asunto y contenido son requeridos" }, { status: 400 });
  }

  // Crear la campaña
  const campaign = await db.emailCampaign.create({
    data: {
      subject,
      content,
      status: send ? "sent" : "draft",
      sentAt: send ? new Date() : null,
    },
  });

  // Si se debe enviar, obtener todos los suscriptores activos
  if (send) {
    const subscribers = await db.newsletter.findMany({
      where: { status: "active" },
      select: { email: true },
    });

    // En un entorno real aquí se integraría con un servicio de email
    // (SendGrid, Resend, Amazon SES, etc.). Por ahora registramos el envío.
    console.log(`📧 Enviando campaña "${subject}" a ${subscribers.length} suscriptores`);

    await db.emailCampaign.update({
      where: { id: campaign.id },
      data: { sentTo: subscribers.length },
    });

    return NextResponse.json({
      campaign,
      sent: true,
      recipients: subscribers.length,
      message: `Campaña enviada a ${subscribers.length} suscriptores`,
    });
  }

  return NextResponse.json({ campaign, sent: false });
}
