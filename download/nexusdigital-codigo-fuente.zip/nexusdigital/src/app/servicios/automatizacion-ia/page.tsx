import type { Metadata } from "next";
import { ServicePage, type ServicePageData } from "@/components/site/service-page";

export const metadata: Metadata = {
  title: "Automatización con Inteligencia Artificial | NexusDigital Colombia",
  description:
    "Implementamos agentes de IA, chatbots inteligentes y automatizaciones que trabajan 24/7. Demo en vivo 5 minutos. Inteligencia artificial aplicada a PYMES en Colombia.",
  alternates: {
    canonical: "https://w14nq5fjb3z1-d.space-z.ai/servicios/automatizacion-ia",
  },
  openGraph: {
    title: "Automatización con Inteligencia Artificial | NexusDigital Colombia",
    description:
      "Implementamos agentes de IA, chatbots inteligentes y automatizaciones que trabajan 24/7. Inteligencia artificial aplicada a PYMES en Colombia.",
    url: "https://w14nq5fjb3z1-d.space-z.ai/servicios/automatizacion-ia",
    type: "website",
  },
};

const DATA: ServicePageData = {
  slug: "automatizacion-ia",
  title: "Automatización con IA | NexusDigital Colombia",
  h1: "Automatización con IA",
  description: "Inteligencia artificial aplicada a tu negocio",
  metaDescription:
    "Implementamos agentes de IA, chatbots inteligentes y automatizaciones que trabajan 24/7. Inteligencia artificial aplicada a PYMES en Colombia.",
  emoji: "🤖",
  intro:
    "Automatización con inteligencia artificial de última generación. Implementamos agentes de IA, chatbots inteligentes y flujos de trabajo que trabajan 24/7 por ti. La inteligencia artificial aplicada a tu negocio en Colombia. Tus clientes atendidos a las 11pm, leads calificados automáticamente, ventas cerradas sin intervención humana.",
  benefits: [
    "Atención al cliente 24/7 sin contratar personal",
    "Reduce hasta 70% el trabajo repetitivo de tu equipo",
    "Agentes de IA que califican leads y agendan citas solos",
    "Integración con WhatsApp, Instagram, tu CRM y web",
    "GPT-4o y modelos de última generación",
    "Reportes automáticos de conversaciones y ventas",
  ],
  features: [
    {
      title: "Agentes de IA para ventas",
      description:
        "Agentes con GPT-4o que conversan con tus clientes como un humano, califican leads, responden FAQs, agendan citas y cierran ventas. Disponibles 24/7 en tu web, WhatsApp y redes sociales.",
    },
    {
      title: "Chatbots inteligentes",
      description:
        "No son chatbots de árbol de decisión antiguos. Son chatbots con IA generativa que entienden contexto, recordatorio de conversaciones previas y escalamiento a humano cuando es necesario.",
    },
    {
      title: "Automatizaciones de procesos",
      description:
        "Conectamos tus herramientas: cuando llega un lead, se guarda en tu CRM, se envía email de bienvenida, se notifica a tu equipo y se agenda seguimiento. Todo automático con n8n y Zapier.",
    },
    {
      title: "Análisis predictivo con IA",
      description:
        "La inteligencia artificial analiza tus datos de ventas para predecir qué clientes van a comprar, qué productos van a tener más demanda y cuándo. Decisiones con datos, no intuición.",
    },
  ],
  pricingLabel: "🤖 Ver demo de IA",
  pricingDetail:
    "Implementaciones desde $2,500,000 COP. Demo en vivo de 5 minutos sin costo. Recuperación de inversión en el primer mes garantizada.",
  faqItems: [
    {
      q: "¿Qué es la inteligencia artificial aplicada a negocios?",
      a: "Es usar modelos de IA (como GPT-4o) para automatizar tareas que antes requerían humanos: atender clientes, calificar leads, generar contenido, analizar datos. No reemplaza a tu equipo, lo potencia para que se enfoque en tareas de alto valor.",
    },
    {
      q: "¿Cómo sé si mi negocio necesita automatización con IA?",
      a: "Si pierdes clientes por no responder a tiempo, si tu equipo hace tareas repetitivas, si tienes muchos leads pero pocos se convierten, si quieres escalar sin contratar más personal. La IA es para ti. En la demo gratis evaluamos tu caso.",
    },
    {
      q: "¿Los clientes notan que están hablando con IA?",
      a: "Configuramos el agente para que sea transparente cuando sea necesario, pero la mayoría de clientes no lo notan. Nuestros agentes tienen personalidad, contexto y empatía. Lo importante es la experiencia, no si es humano o IA.",
    },
    {
      q: "¿Cuánto cuesta implementar un agente de IA?",
      a: "Desde $2,500,000 COP una sola vez (setup + entrenamiento). Mensualidad desde $300,000 COP por mantenimiento + uso de APIs. Recuperación de inversión típica: 30 días. Garantía: si no recuperas la inversión en 90 días, seguimos trabajando sin costo.",
    },
  ],
};

export default function Page() {
  return <ServicePage data={DATA} />;
}
