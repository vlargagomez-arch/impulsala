# Impulsala — Agencia Web + CRM + IA

## 🚀 Deploy en Vercel (30-40 min)

**Lee `deploy-kit/GUIA-HERMES.md`** — guía completa paso a paso.

## Instalación local
```bash
bun install
cp .env.example .env  # Editar con credenciales de Supabase
bunx prisma generate
bunx prisma db push
bun run dev
```

## Credenciales CRM
- Email: admin@impulsala.com
- Password: nexus2026

## Características
- Next.js 16 + App Router
- CRM (citas, leads, newsletter, campañas, blog)
- ImpulsalaBot (chatbot IA)
- Gmail integration (emails reales)
- Google Calendar + Meet automático
- WhatsApp recordatorios manuales
- Blog con 25+ artículos
- SEO técnico completo
- Tailwind CSS 4 + shadcn/ui
- Logo {i} con gradiente índigo→fucsia
