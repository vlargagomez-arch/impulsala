#!/bin/bash
# Watchdog: mantiene el servidor vivo siempre.
# Si se cae, lo reinicia en 3 segundos.
# Usa `next dev` para hot-reload instantáneo (cambios visibles sin rebuild).

cd /home/z/my-project

# Restaurar .env si se resetea
restore_env() {
  if [ $(wc -l < .env) -lt 5 ]; then
    cat > .env << 'EOF'
DATABASE_URL=file:/home/z/my-project/db/custom.db
NEXTAUTH_SECRET=impulsala-crm-secret-2026-7f3a9b2c8e1d4a6f9b0c5e2d7a4f1b8e
NEXTAUTH_URL=https://d1m686vag521-d.space-z.ai
CRM_ADMIN_EMAIL=admin@impulsala.com
CRM_ADMIN_PASSWORD=nexus2026
NEXT_PUBLIC_SITE_URL=https://d1m686vag521-d.space-z.ai
EMAIL_USER=vlargagomez@gmail.com
EMAIL_PASS=dwtuomxmrxntggug
GOOGLE_CLIENT_ID=321912503836-eeit8krehh18hp04fsqfst3jsjfv7gv4.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
GOOGLE_REDIRECT_URI=https://d1m686vag521-d.space-z.ai/api/google-calendar/callback
GOOGLE_SHEETS_WEBHOOK_URL=
EOF
    echo "[$(date)] .env restaurado"
  fi
}

# Matar procesos anteriores
pkill -9 -f "server.js" 2>/dev/null
pkill -9 -f "next dev" 2>/dev/null
pkill -9 -f "next-server" 2>/dev/null
sleep 2

echo "=== WATCHDOG INICIADO ==="
echo "Servidor: next dev (hot-reload instantáneo)"
echo "Preview: https://preview-chat-7c3eb161-784b-42ef-9f58-e1411802aea3.space-z.ai/"
echo "Local: http://localhost:3000"
echo "Auto-restart: ACTIVADO"
echo ""

# Loop infinito
while true; do
  # Restaurar .env si se resetea
  restore_env

  # Verificar si el servidor está vivo
  if curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/ 2>/dev/null | grep -q "200"; then
    # Servidor vivo, esperar 30 segundos
    sleep 30
  else
    # Servidor caído, reiniciar
    echo "[$(date)] Servidor caído. Reiniciando..."

    # Matar todo
    pkill -9 -f "server.js" 2>/dev/null
    pkill -9 -f "next dev" 2>/dev/null
    pkill -9 -f "next-server" 2>/dev/null
    sleep 2

    # Restaurar .env
    restore_env

    # Iniciar servidor con next dev (hot-reload)
    setsid bash -c 'cd /home/z/my-project && bun run dev > dev.log 2>&1' < /dev/null &
    disown

    # Esperar a que arranque
    sleep 10

    # Verificar
    code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/ 2>/dev/null)
    if [ "$code" = "200" ]; then
      echo "[$(date)] ✅ Servidor reiniciado correctamente"
    else
      echo "[$(date)] ⚠️ Servidor aún no responde, esperando más..."
      sleep 10
      code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/ 2>/dev/null)
      if [ "$code" = "200" ]; then
        echo "[$(date)] ✅ Servidor reiniciado (segundo intento)"
      else
        echo "[$(date)] ❌ Servidor no arranca, reintentando en 30s..."
        sleep 30
      fi
    fi
  fi
done
