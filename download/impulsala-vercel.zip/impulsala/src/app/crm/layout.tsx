import { NextAuthProvider } from "@/components/crm/session-provider";

export default function CrmLayout({ children }: { children: React.ReactNode }) {
  return <NextAuthProvider>{children}</NextAuthProvider>;
}
