import type { Metadata } from "next";
import { ServicePage, type ServicePageData } from "@/components/site/service-page";

export const metadata: Metadata = {
  title: "Desarrollo Web Profesional en Bogotá | Impulsala",
  description:
    "Desarrollo web a medida para PYMES en Colombia: e-commerce, CRM, aplicaciones web y sistemas internos. Presupuesto en 24 horas. Resultados garantizados.",
  alternates: {
    canonical: "https://w14nq5fjb3z1-d.space-z.ai/servicios/desarrollo-web",
  },
  openGraph: {
    title: "Desarrollo Web Profesional en Bogotá | Impulsala",
    description:
      "Desarrollo web a medida para PYMES en Colombia: e-commerce, CRM, aplicaciones web y sistemas internos.",
    url: "https://w14nq5fjb3z1-d.space-z.ai/servicios/desarrollo-web",
    type: "website",
  },
};

const DATA: ServicePageData = {
  slug: "desarrollo-web",
  title: "Desarrollo Web Profesional en Bogotá | Impulsala",
  h1: "Desarrollo Web",
  description: "Desarrollo web profesional",
  metaDescription:
    "Desarrollo web a medida para PYMES en Colombia: e-commerce, CRM, aplicaciones web y sistemas internos. Presupuesto en 24 horas.",
  emoji: "💻",
  intro:
    "Creamos sitios web y aplicaciones a medida que cargan rápido, se ven increíbles y convierten visitantes en clientes. Especialistas en desarrollo web para PYMES en Bogotá y toda Colombia. Tu proyecto de desarrollo web entregado en tiempo récord.",
  benefits: [
    "Sitios web que cargan en menos de 2 segundos",
    "Diseño responsivo que se ve perfecto en móvil, tablet y PC",
    "Código limpio y escalable, fácil de mantener",
    "Integración con pasarelas de pago y herramientas que ya usas",
    "Panel de administración intuitivo, sin conocimientos técnicos",
    "Soporte técnico 24/7 en español",
  ],
  features: [
    {
      title: "Sitios web corporativos",
      description:
        "Tu presencia digital profesional con desarrollo web de alto nivel. Páginas que comunican tu propuesta de valor y generan confianza desde el primer scroll.",
    },
    {
      title: "Plataformas e-commerce",
      description:
        "Tiendas online que venden solas. Integración con Wompi, PayU, Mercado Pago y todas las pasarelas de pago de Colombia. Carrito de compras, gestión de inventario y analíticas.",
    },
    {
      title: "CRM y sistemas internos",
      description:
        "Software a medida para tu empresa. Gestión de clientes, inventarios, facturación, reportes. Automatizamos lo que hoy haces manualmente.",
    },
    {
      title: "Aplicaciones web progresivas (PWA)",
      description:
        "Apps que funcionan offline y se instalan como aplicaciones nativas. La mejor experiencia de usuario sin pagar comisiones a App Store o Play Store.",
    },
  ],
  pricingLabel: "💻 Cotizar mi proyecto",
  pricingDetail:
    "Proyectos de desarrollo web desde $2,000,000 COP. Presupuesto personalizado en 24 horas. Sin compromiso.",
  faqItems: [
    {
      q: "¿Cuánto cuesta desarrollar una página web?",
      a: "Un sitio web profesional parte desde $2,000,000 COP para PYMES. El precio final depende del alcance: número de páginas, funcionalidades (e-commerce, reservas, login), integraciones y nivel de personalización. Te damos un presupuesto exacto en 24 horas.",
    },
    {
      q: "¿En cuánto tiempo entregan?",
      a: "Sitios web corporativos: 2-3 semanas. E-commerce: 4-6 semanas. Sistemas a medida: 6-12 semanas según complejidad. Trabajamos con sprints semanales y entregas parciales para que veas el progreso.",
    },
    {
      q: "¿Usan WordPress o código a medida?",
      a: "Ambos. Para sitios corporativos sencillos usamos WordPress con tema personalizado. Para proyectos complejos (e-commerce, CRM, sistemas) usamos Next.js, React y Node.js para máximo rendimiento y flexibilidad.",
    },
    {
      q: "¿El sitio web será mío?",
      a: "100% tuyo. Te entregamos todos los códigos fuente, credenciales de hosting, dominio y acceso completo. Sin contratos de permanencia. Te enseñamos a gestionarlo si quieres.",
    },
  ],
};

export default function Page() {
  return <ServicePage data={DATA} />;
}
