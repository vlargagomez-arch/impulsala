import { PrismaClient } from '@prisma/client'
import fs from 'fs'
import path from 'path'

// Detectar el path correcto de la BD
function getDatabasePath(): string {
  // 1. Si DATABASE_URL está seteada y el archivo existe, usarla
  const envUrl = process.env.DATABASE_URL
  if (envUrl && envUrl.startsWith('file:')) {
    const filePath = envUrl.replace('file:', '')
    if (fs.existsSync(filePath)) {
      return envUrl
    }
    // Si es relativa, probar desde diferentes directorios
    if (!path.isAbsolute(filePath)) {
      const candidates = [
        filePath,                                    // relativa al cwd
        path.join(process.cwd(), filePath),          // absoluta desde cwd
        path.join(process.cwd(), '..', filePath),    // un nivel arriba
        path.join('/app', filePath),                 // /app en producción
        path.join('/app', 'db', 'custom.db'),        // /app/db/custom.db
        '/app/db/custom.db',                         // path absoluto producción
      ]
      for (const candidate of candidates) {
        if (fs.existsSync(candidate)) {
          return `file:${candidate}`
        }
      }
    }
  }

  // 2. Paths por defecto según entorno
  const defaultPaths = [
    '/app/db/custom.db',                            // producción (FC empaquetada)
    path.join(process.cwd(), 'db', 'custom.db'),    // desarrollo (cwd)
    path.join(process.cwd(), '..', 'db', 'custom.db'), // desarrollo (anidado)
    '/home/z/my-project/db/custom.db',              // desarrollo original
  ]

  for (const p of defaultPaths) {
    if (fs.existsSync(p)) {
      return `file:${p}`
    }
  }

  // 3. Último recurso: devolver lo que tenga .env
  return envUrl || 'file:db/custom.db'
}

const databaseUrl = getDatabasePath()

// Forzar DATABASE_URL al path correcto
process.env.DATABASE_URL = databaseUrl

console.log(`🗄️ [DB] Using database at: ${databaseUrl}`)

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'production' ? ['error', 'warn'] : ['query'],
    datasources: {
      db: {
        url: databaseUrl,
      },
    },
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
