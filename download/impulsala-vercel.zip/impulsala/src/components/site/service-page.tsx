import type { Metadata } from "next";
import Link from "next/link";
import { Navbar } from "@/components/site/navbar";
import { Footer } from "@/components/site/footer";
import { StickyCTA } from "@/components/site/sticky-cta";
import { ScrollProgress } from "@/components/site/top-progress-bar";
import WhatsAppButton from "@/components/site/ai-chat-fab";
import { ArrowRight, Check, Star, Sparkles } from "lucide-react";

const SITE_URL = "https://w14nq5fjb3z1-d.space-z.ai";

export type ServicePageData = {
  slug: string;
  title: string;
  h1: string;
  description: string;
  metaDescription: string;
  emoji: string;
  intro: string;
  benefits: string[];
  features: { title: string; description: string }[];
  pricingLabel: string;
  pricingDetail: string;
  faqItems: { q: string; a: string }[];
};

export function ServicePage({ data }: { data: ServicePageData }) {
  const metadata: Metadata = {
    title: data.title,
    description: data.metaDescription,
    alternates: { canonical: `${SITE_URL}/servicios/${data.slug}` },
    openGraph: {
      title: data.title,
      description: data.metaDescription,
      url: `${SITE_URL}/servicios/${data.slug}`,
      type: "website",
    },
  };

  return (
    <>
      <ServicePageContent data={data} />
    </>
  );
}

function ServicePageContent({ data }: { data: ServicePageData }) {
  return (
    <div className="relative flex min-h-screen flex-col bg-background">
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-primary/5 blur-[120px]" />
        <div className="absolute bottom-0 right-0 h-[400px] w-[400px] rounded-full bg-accent/5 blur-[100px]" />
      </div>

      <ScrollProgress />
      <Navbar />

      <main className="flex-1 pt-24 pb-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Breadcrumb */}
          <nav className="mb-6 flex items-center gap-2 text-xs text-muted-foreground">
            <Link href="/" className="hover:text-foreground transition-colors">Inicio</Link>
            <span>/</span>
            <Link href="/servicios" className="hover:text-foreground transition-colors">Servicios</Link>
            <span>/</span>
            <span className="text-foreground">{data.h1}</span>
          </nav>

          {/* Hero */}
          <div className="text-center">
            <span className="inline-flex items-center gap-2 rounded-full border border-indigo-500/20 bg-indigo-500/10 px-3 py-1 text-xs font-medium text-indigo-600 dark:text-indigo-400">
              <Sparkles className="h-3 w-3" />
              {data.emoji} {data.h1}
            </span>
            <h1 className="mt-5 text-3xl font-extrabold tracking-tight sm:text-4xl md:text-5xl">
              {data.h1} en{" "}
              <span className="bg-gradient-to-r from-indigo-500 via-fuchsia-500 to-pink-500 bg-clip-text text-transparent">
                Bogotá y toda Colombia
              </span>
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              {data.intro}
            </p>
            <div className="mt-6 flex items-center justify-center gap-1 text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-4 w-4 fill-current" />
              ))}
              <span className="ml-1.5 text-sm font-semibold text-foreground">4.9/5 · 150+ empresas en Colombia</span>
            </div>
          </div>

          {/* CTA */}
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <a
              href="/diagnostico-gratis"
              className="group flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/30 transition-all hover:-translate-y-0.5 hover:shadow-indigo-500/50 sm:w-auto"
            >
              🗓️ {data.emoji} {data.pricingLabel}
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
          </div>
          <p className="mt-3 text-center text-xs text-muted-foreground">
            ✓ Sin tarjeta de crédito · ✓ Sin compromiso · ✓ Respuesta en menos de 2 horas
          </p>

          {/* Benefits */}
          <section className="mt-16">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              ¿Por qué elegir nuestro {data.h1.toLowerCase()}?
            </h2>
            <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {data.benefits.map((b, i) => (
                <div
                  key={i}
                  className="flex items-start gap-3 rounded-xl border border-border/60 bg-card/40 p-4 backdrop-blur-sm"
                >
                  <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-primary/15">
                    <Check className="h-3.5 w-3.5 text-primary" />
                  </span>
                  <span className="text-sm text-foreground/90">{b}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Features */}
          <section className="mt-12">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              Qué incluye nuestro servicio
            </h2>
            <div className="mt-6 space-y-4">
              {data.features.map((f, i) => (
                <div
                  key={i}
                  className="rounded-2xl border border-border/60 bg-card/40 p-5 backdrop-blur-sm"
                >
                  <h3 className="text-base font-semibold text-foreground">{f.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.description}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Pricing */}
          <section className="mt-12 rounded-2xl border border-border/60 bg-gradient-to-br from-indigo-500/5 via-fuchsia-500/2 to-transparent p-6 backdrop-blur-sm sm:p-8">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl text-center">
              {data.pricingLabel}
            </h2>
            <p className="mt-3 text-center text-sm text-muted-foreground">{data.pricingDetail}</p>
            <div className="mt-6 flex justify-center">
              <a
                href="/diagnostico-gratis"
                className="group inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/30 transition-all hover:-translate-y-0.5"
              >
                Agenda tu diagnóstico gratis
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </a>
            </div>
          </section>

          {/* FAQ */}
          <section className="mt-12">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl text-center">
              Preguntas frecuentes
            </h2>
            <div className="mt-6 space-y-3">
              {data.faqItems.map((item, i) => (
                <details key={i} className="group rounded-xl border border-border/60 bg-card/40 backdrop-blur-sm">
                  <summary className="flex cursor-pointer items-center justify-between gap-3 p-4 text-sm font-semibold text-foreground">
                    {item.q}
                  </summary>
                  <div className="px-4 pb-4">
                    <p className="text-xs leading-relaxed text-muted-foreground">{item.a}</p>
                  </div>
                </details>
              ))}
            </div>
          </section>

          {/* Final CTA */}
          <section className="mt-16 rounded-2xl border border-border/60 bg-gradient-to-br from-indigo-500/10 via-fuchsia-500/5 to-transparent p-8 backdrop-blur-sm text-center">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              ¿Listo para empezar tu proyecto de {data.h1.toLowerCase()}?
            </h2>
            <p className="mx-auto mt-3 max-w-md text-sm text-muted-foreground">
              La agencia #1 en Colombia para PYMES. Agenda tu diagnóstico gratuito hoy y recibe tu propuesta en menos de 24 horas.
            </p>
            <a
              href="/diagnostico-gratis"
              className="group mt-6 inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/30 transition-all hover:-translate-y-0.5"
            >
              🗓️ Agendar diagnóstico gratis
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <p className="mt-3 text-xs text-muted-foreground">
              📅 Horarios disponibles: Lunes a Viernes, 9am - 6pm (Bogotá, Colombia)
            </p>
          </section>
        </div>
      </main>

      <Footer />
      <StickyCTA />
      <WhatsAppButton />
    </div>
  );
}
